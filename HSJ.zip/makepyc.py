#！/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 2021-02-20 23:15:06
Author: wzh
Platform: Python 3.7.4 Windows-10-10.0.18362-SP0 AMD64
Email: hrcl2015@126.com
Wechat: hrcl2015(微信号)
Filename: makepyc.py
Description : 
    加载各种模块，用于生成pyc文件
"""

import comm
import HSJ_AES
import logger
import m2m
import myaes
import mydatabase
import update
import models

if __name__=="__main__":
    
    pass

