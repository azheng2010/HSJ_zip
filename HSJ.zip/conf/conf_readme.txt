﻿[Version]
version = 0.1.1
#版本信息

[Client]
uainfo = 
#客户端信息

[Notice]
email = 12345678@qq.com
#提醒邮箱

[Work-Mode]
debug = 0
#工作模式 调试/工作 1/0

[Answer-Method]
Method = Auto
#答题方式 自动/手动 Auto/Manual

[UserInf]
user = 13870088955
#账号
password = 088955
#密码

[Correctrate-Setting]
max = 85
#正确率上限(百分比)
min = 75
#正确率下限(百分比)

[Search-Switch]
#搜索器开关，4个开关 0表示关闭，1表示打开
OwnData = 1
#专有题库
ComData = 1
#公共题库
WebDB = 0
#网络数据库
WebSearch = 0
#网络搜索

